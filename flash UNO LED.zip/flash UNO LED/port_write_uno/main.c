#include <avr/io.h>
#include <stdio.h>

void Delay(void);

int main(void)
{
	//DDRB = 0x20;			// set bit 5 of DDR register which makes PB5 an output
    DDRB = 0x02;  // use PB1
	while(1)
	{
		PORTB = 0xFF;		// switch LED on
		Delay();
		PORTB = 0x00;		// switch LED off
		Delay();
	}
}

void Delay(void)
{
	volatile unsigned long count = 15000;

	while (count--);
}